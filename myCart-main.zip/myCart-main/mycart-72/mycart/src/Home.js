import React from 'react'
import "./Home.css"
import background_main_1 from './img/background/mycart_home.png'
import Product from './Product'
import redbull from './img/product/demo_product.jpg'
import snacks_bucket_1 from "./img/product/mycart_product_1.png"
import Tshirt from "./img/product/mycart_product_2.png"
import redbull_drink from "./img/product/mycart_product_3.png"
import notebook from "./img/product/mycart_product4.png"
import snack_bucket_2 from "./img/product/mycart_product5.png"
import food_bucket_1 from "./img/product/mycart_product6.png"
import food_bucket_2 from "./img/product/mycart_product7.png"
import men_kit from "./img/product/men_kit.png"
import women_kit from "./img/product/women_kit.png"
import moniter from "./img/product/moniter.png"

import Footer from './Footer'



//Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -- terminal code for bypass and use firebase
function Home() {
    return (
        <div className="home">
           <div className="home__container">
               <img className="home__image1" src={background_main_1} alt="" />

            <div className="home__row">
                {/* product */}
                <Product 
                id="000000001"
                title="The Buddy Pack (Lays Potato chips - 78gm, Kurkure - 90gm, Coca-cola - 300ml) - Each 2 pack "
                price={110}
                image={snacks_bucket_1} 
                rating={5}
                />
                
                <Product 
                id="000000002" 
                title="Celebrate Pawri trend with Pawri T-shirt ( Black )"
                price={299}
                image={Tshirt} rating={4}/>
                


            </div>

            <div className="home__row">
                {/* product */}
                <Product
                 id="000000003"
                 title="The Wings Pack ( 2 Redbull - 350ml, 1 Coco-cola - 300ml )" 
                 price={249}
                image={redbull_drink} 
                rating={5}
                />
                <Product
                id="000000004" 
                title="The Boy's Pack ( Denver Deo - 180ml, Beer shampoo - 100ml, Garnier Men facewash -  50ml, Gilette kit, Cinthol soap - 5 pack)"
                price={599}
                image={men_kit}
                rating={4}
                />
                <Product 
                id="000000005" 
                title="The Girl's Pack ( Engage Deo - 180ml, TRESemme shampoo - 100ml, Dove soap - 3 pack, whisper, Himalayan - 50ml)" 
                price={449}
                image={women_kit}  
                rating={3}
                />
                
            </div>

            <div className="home__row">
                {/* product */}
                <Product
                 id="000000006"
                 title="Homework pack ( 3 Classmate Notebook, 6 cello pen + one free pen )" 
                 price={149}
                image={notebook} 
                rating={5}
                />
                <Product
                id="000000007" 
                title="Burger time ( 1 veg burger, 600ml Coca-cola ) - Delivery time within 30min."
                price={99}
                image={snack_bucket_2}
                rating={4}
                />
                <Product 
                id="000000008" 
                title="Vegetarian Premium thali - Delivery time within 30min - Menu Changed every day." 
                price={149}
                image={food_bucket_1} 
                rating={4}
                />
                 <Product 
                id="000000009" 
                title="Vegetarian Deluxe thali - Delivery time within 30min - Menu Changed every day." 
                price={249}
                image={food_bucket_2} 
                rating={5}
                />
                
            </div>

            <div className="home__row">
                {/* product */}
              
                <Product
                id="000000010" 
                title="Shop up to Rs.2000 and get a chance to win Samsung curved 34-inch monitor. Buy Scratch card at only Rs.299*" 
                price={299}
                image={moniter} 
                rating={4}
                />
             
                
            </div>

               </div> 
        </div>
        
    )
   
}


export default Home
