import React, { useState, useEffect } from 'react'
import './Feedback.css'
import firebase from "firebase";
import { db } from "../firebase";
function Booking() {

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [message, setMessage] = useState("");
  
    const [loader, setLoader] = useState(false);
  
    const handleSubmit = (e) => {
      e.preventDefault();
      setLoader(true);
  
      db.collection("feedback")
        .add({
          name: name,
          email: email,
          message: message,
        })
        .then(() => {
          setLoader(false);
         // alert("Your message has been submitted👍");
          // Show alert
  document.querySelector(".alert").style.display = "block";

  // Hide alert after 3 seconds
  setTimeout(function () {
    document.querySelector(".alert").style.display = "none";
  }, 5000);

  // Clear form
  document.querySelector(".contact-form").reset();

        })
        .catch((error) => {
          alert(error.message);
          setLoader(false);
        });
  
      setName("");
      setEmail("");
      setMessage("");
    };
  

    return (
        <div className="form">
            <h1>Feedback form</h1>
            <p className="p">Give us feedback and help us to improve our Service & Products</p>
            {/* <p className="p">Send a message and we will get back to you within 24 hours.</p> */}
            <div class="alert">Thank you! for your feedback</div>

            <form className="contact-form" onSubmit={handleSubmit}>

      <label>Name</label>
      <input
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <label>Email</label>
      <input
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />

      <label>Feedback</label>
      <textarea
        placeholder="Feedback Message"
        value={message}
        cols="30"
        rows="10"
        onChange={(e) => setMessage(e.target.value)}
      ></textarea>

        <button type="submit">Submit</button>
    </form>
    
        </div>
    )
}

export default Booking
