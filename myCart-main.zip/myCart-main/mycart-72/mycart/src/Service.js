import React from 'react'
import Service from './Services'
import redbull from './img/product/demo_product.jpg'
import laundry from './img/service/service_laundry.png'
import laptop from  './img/service/service_laptop.png'
function service() {
    return (
        <div className="service">
            <div className="service__container">

            <div className="home__row">
                {/* product */}
                <Service
                id="000000001"
                title="Weekly Laundry Service Pass ( Get one-week laundry service from using this pass - all details about your service provider mention on the pass ) - Book your pass today. "
                price={129}
                image={laundry} 
                rating={5}
                />
                
                <Service 
                id="000000002" 
                title="One-Day Laptop repair service pass ( *exclude extra things to be used in repair time.)"
                price={250}
                image={laptop} rating={4}/>
                


            </div>


            </div>
              
        </div>
    )
}

export default service
