import React from 'react'
import './Services.css'
import { useStateValue } from './StateProvider';
import { useHistory } from 'react-router';
import img from './img/product/demo_product.jpg'

function Services({id, title, image, price, rating}) {
    const history = useHistory();
    const [{basket}, dispatch] = useStateValue()
    console.log('this is the basket>>>', basket);

    const addToBasket = () => {
        // dispatch the item into the data layer
        dispatch({
          type: "ADD_TO_BASKET",
          item: {
            id: id,
            title: title,
            image: image,
            price: price,
            rating: rating,
          },
        });
      };

    return (
        <div className="service">
            <div className="service__info">
                <p>{title}</p>
                <p className="service__price">
            <small><b>&#8377;</b></small>
            <strong>{price}</strong>
        </p>
        <div className="service__rating">
            {Array(rating)
            .fill()
            .map((_, i)=>(
                <p>&#9733;</p> 
            ))}
        
        
       {/*  <p>&#9734; blank star</p> */}
        </div>
            </div>
            <img src={image} alt="" />

            <button onClick={addToBasket}>book now</button>
            

        </div>
    )
}

export default Services
