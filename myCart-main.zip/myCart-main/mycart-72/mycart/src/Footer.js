import React from "react";
import { Link } from "react-router-dom";
import {
Box,
Container,
Row,
Column,
FooterLink,
Heading,
} from "./FooterStyle";

const Footer = () => {
return (
	<Box>
	<h1 style={{ color: "green",
				textAlign: "center",
				marginTop: "-50px",
                marginBottom: "20px" }}>
		Project Mycart : Made by Computer Science Students - GNIT GGSIPU.
	</h1>
	<Container>
		<Row>
		<Column>
			<Heading>About Us</Heading>
            <FooterLink href="#">College</FooterLink>
			<FooterLink href="#">University</FooterLink>
			<FooterLink href="#">Developers</FooterLink>
            <FooterLink href="#">Github link</FooterLink>

			
		</Column>
		<Column>
			<Heading style={{
                fontSize:"17px"
            }}>Products &#38; Services</Heading>
            <FooterLink href="#">Daily need</FooterLink>
            <FooterLink href="#">Electronic service</FooterLink>
			<FooterLink href="#">Find PG's &#38; Hostels</FooterLink>
			<FooterLink href="#">Become a seller</FooterLink>
			
		</Column>
		{/* <Column>
			<Heading>Contact Us</Heading>
			<FooterLink href="https://www.linkedin.com/in/rahul-kumar-68871b165/"> Rahul Kumar</FooterLink>
            <FooterLink href="https://www.linkedin.com/in/sandeep-kumar-7aa63619b/"> Sandeep Kumar</FooterLink>
            <FooterLink href="https://www.linkedin.com/in/somya-rajput-879850204/"> Sheetal Rawat </FooterLink>
			<Link to= '/Feedback'>
			<FooterLink href="#" >Feedback</FooterLink>
			</Link>
		</Column> */}
		<Column>
			<Heading>Social Media</Heading>
			<FooterLink href="#">
			<i className="fab fa-facebook-f">
				<span style={{ marginLeft: "10px" }}>
				Facebook
				</span>
			</i>
			</FooterLink>
			<FooterLink href="#">
			<i className="fab fa-instagram">
				<span style={{ marginLeft: "10px" }}>
				Instagram
				</span>
			</i>
			</FooterLink>
			<FooterLink href="#">
			<i className="fab fa-twitter">
				<span style={{ marginLeft: "10px" }}>
				Twitter
				</span>
			</i>
			</FooterLink>
			<FooterLink href="#">
			<i className="fab fa-linkedin">
				<span style={{ marginLeft: "10px" }}>
				Linkedin
				</span>
			</i>
			</FooterLink>
		</Column>
		</Row>
	</Container>
    {/* //copyright section  */}
    <Column>
    <p
    style={{ color: "white",
    textAlign: "center",
   flexShrink:0,
   marginTop:"25",
   marginBottom:"2",
   fontSize: "18px"
   }}>
       &#169; Copyright goes to Project Developer's -
       <FooterLink href="#"> <b>Ashutosh,</b></FooterLink>
       <FooterLink href="#"> <b>Awnish negi, </b></FooterLink>
       <FooterLink href="#"> <b>kartik pandey</b></FooterLink>
       </p>
    </Column>
	</Box>
    
);
};
export default Footer;
