import React from 'react'
import "./Product.css"
import { useStateValue } from './StateProvider';

function Product({id, title, image, price, rating}) {
    const [{basket}, dispatch] = useStateValue()

console.log('this is the basket>>>', basket);

    const addToBasket = () => {
      // dispatch the item into the data layer
      dispatch({
        type: "ADD_TO_BASKET",
        item: {
          id: id,
          title: title,
          image: image,
          price: price,
          rating: rating,
        },
      });
    };
    
    return (
        <div className="product">
           <div className="product__info">
    <p>{title}</p>
        <p className="product__price">
            <small><b>&#8377;</b></small>
            <strong>{price}</strong>
        </p>
        <div className="product__rating">
            {Array(rating)
            .fill()
            .map((_, i)=>(
                <p>&#9733;</p> 
            ))}
        
        
       {/*  <p>&#9734; blank star</p> */}
        </div>
           </div>
<img src={image} alt=""/>

<button onClick={addToBasket}>Add to Cart</button>

        </div>
    )
}

export default Product



/* this is statice side in above i make dyanmic to add multiple products
function () {
    return (
        <div className="product">
           <div className="product__info">
    <p>Hey redbull gives you wings!</p>
        <p className="product__price">
            <small><b>&#8377;</b></small>
            <strong>199</strong>
        </p>
        <div className="product__rating">
        <p>&#9733;</p>
        <p>&#9733;</p>
        <p>&#9733;</p>
        <p>&#9733;</p>
        <p>&#9734; blank star</p>
        </div>
           </div>
<img src={redbull} alt=""/>

<button>Add to Cart</button>

        </div>
    )
} */