import firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyABsO3ykOQ6lSRp04kocAmLII96_BLiso8",
  authDomain: "mycart-72.firebaseapp.com",
  projectId: "mycart-72",
  storageBucket: "mycart-72.appspot.com",
  messagingSenderId: "208143128279",
  appId: "1:208143128279:web:72762e0d8729898fd40292",
  measurementId: "G-T6NPN0CTBJ"
};
const firebaseApp = firebase.initializeApp(firebaseConfig);


const db = firebaseApp.firestore(); 
const auth =firebase.auth();

export{db, auth};